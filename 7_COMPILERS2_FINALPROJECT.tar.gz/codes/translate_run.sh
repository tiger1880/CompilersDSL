g++ translated.cpp -lGL -lglut -lGLU
./a.out